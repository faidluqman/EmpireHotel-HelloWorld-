Empire Hotel

import sql file below on your phpmyadmin 
Database: empire.sql

Admin Login
Username: admin
Password: admin123

