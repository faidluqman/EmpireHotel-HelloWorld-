<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Empire Hotel</title>

        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Boostrap Core CSS-->
        <link rel="stylesheet" href="css/bootstrap.min.css"> 
        
        <!-- Main CSS -->
        <link rel="stylesheet" href="css/style.css">
        
        <!-- Gallery -->
        <link rel="stylesheet" href="css/touchTouch.css">
        
        <!-- Animate CSS -->
        <link href="css/animate.css" rel="stylesheet">

        <!-- Google fonts -->
        <link href='http://fonts.googleapis.com/css?family=Oxygen:400,300' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Qwigley" >
        <!-- Font awesome -->
        <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

   </head>
   <!-- Start wrapper -->
   <div class="wrapper">
  	  <div class="col-md-12">