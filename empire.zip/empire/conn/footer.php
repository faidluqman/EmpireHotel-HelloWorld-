 <!-- Start footer -->
          <div class="footer col-md-6 col-xs-offset-3">
             <h5>Copyright 2020
                 <a href="#"><i class="fa fa-facebook fa-1x icon1"></i></a>
                 <a href="#"><i class="fa fa-twitter fa-1x icon1"></i></a>
                 <a href="#"><i class="fa fa-instagram fa-1x icon1"></i></a>
             </h5>
          </div>
          <!-- End footer -->
 </div>
      <!-- End col-md-12 -->

   </div>
   <!-- End wrapper -->

      
   <!-- jQuery Version 1.11.0 -->
   <script src="js/jquery-1.11.0.js"></script>
   <!-- Boostrap JS -->
   <script src="js/bootstrap.min.js"></script>
   <!-- Smooth scroll JS -->
   <script src="js/smoothscroll.js"></script>
   
   <!-- Wow JavaScript -->
   <script src="js/wow.js"></script>
    
   <script>
   new WOW().init();
   </script>


</body>
</html>