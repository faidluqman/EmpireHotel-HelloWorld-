<?php
include('conn/header.php');
include('conn/nav.php');
?>
 <!-- Start margin -->
         <div class="margin-about">
             <!-- Start left column -->
             <div class="box-about col-md-4 col-xs-offset-1">
               <h3 class="heading-inner">About</h3>
                  <div class="hr"></div>
                    <h4>Empire Hotel is located at the Beach of the town of Port Dickson
					center on the very beautiful pebble beach and represents a perfect place for your 
					holiday with several activities and relaxed wellness treatments.</h4>
                    <h4>This four-star hotel has more than 40 comfortably equipped rooms.The most rooms 
					have a beautiful sea view. All rooms are modern and have air condition, balcony, 
					bathroom, hair dryer, SAT TV, safe, phone and internet access.</h4>
                    <h4>We have large rooms with modern facilities. We offer our guest some unique 
					facilities such as a Cafe Restaurant, Swimming Pool, Fitness Center, Conference Facilities and Social 
					Function Services.Buffet breakfast is served each morning.Guest car parking is limited and 
					will be available on a first come, first served basis(free)</h4>        
                   
             </div>
             <!-- End left column -->
             
             <!-- Start right image -->
             <div class="col-md-6 wow fadeIn" data-wow-delay="0.1s">
               <img src="img/2.jpg" alt="" class="photo-about"/> 
             </div>
             <!-- End right image -->
         </div>
         <!-- End margin -->

<?php
include('conn/footer.php');
?>